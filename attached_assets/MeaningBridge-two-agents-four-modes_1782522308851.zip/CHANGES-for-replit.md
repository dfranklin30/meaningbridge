# Changes to bring into Replit — Two agents, four modes

This makes all **four companion modes** real. Before, only two worked; "Journaling" and "Practices" silently reused the meaning prompt. Now each mode has its own dedicated agent behavior.

## The two agents → four modes

- **Meaning-Focused Grief Therapy Agent**
  - **Meaning-Focused Support** (`meaning`) — re-authoring the story of the loss and identity
  - **Journaling Coach** (`journaling`) — one-at-a-time grief writing prompts *(new)*
  - **Self-Guided Practices** (`practices`) — grounding, ritual, values reflection *(new)*
- **Continuing Bonds Agent**
  - **Continuing Bonds Dialogue** (`continuing-bonds`) — tending the ongoing relationship

All four share the same safe voice, care-tier behavior, hard limits, and crisis footer that were already in your code.

## Files to copy into Replit (only these 3 changed)

1. `artifacts/api-server/src/lib/prompts.ts`
   — added `journalingSystemPrompt`, `practicesSystemPrompt`, and a `systemPromptForMode(mode, ctx)` dispatcher.

2. `artifacts/api-server/src/routes/chat.ts`
   — now calls `systemPromptForMode(session.mode, …)` instead of the old two-way if/else, so every mode gets its correct prompt.

3. `artifacts/meaningbridge/src/pages/companion/index.tsx`
   — added the two missing mode cards (Journaling Coach, Self-Guided Practices) so users can actually pick them.

## How to apply in Replit

For each file above: open it in Replit, select all, and paste in the new version (or drag the file in to overwrite). No database changes, no new packages, no config changes needed — the `mode` field and API contract already supported four modes.

After pasting, just let Replit restart the app and open the Companion page — you'll see four cards.

## Verified

All three files pass a syntax/transpile check. (The `tsconfig.base.json` warning you may see is unrelated — that file lives in your Replit project but wasn't included in the zip download.)

## Not changed yet (next options)

- Stronger crisis detection (add a model-based second layer beyond keywords)
- The clinician/therapist side (locator + admin oversight dashboard)
- Mode-specific opening messages in the chat view
