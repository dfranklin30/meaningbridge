# MeaningBridge AI Upgrade Package — hand this folder to Replit Agent

This package contains working modules for two upgrades. Most of the design and
code is done; Replit Agent's job is **wiring, not inventing**.

1. **Proactive companion** — from the moment a person logs in, the companion
   knows them, greets them personally, and offers one meaningful next step
   (journal, reflection, upcoming therapist session). Memory persists across
   visits. Gentle opt-in email check-ins bring people back — no streaks, no
   gamification.
2. **Loved-one living portrait** — a person uploads one photo of the person
   they lost; the system creates a gently animated portrait (breathing,
   blinks) that appears inside the Meaning Reconstruction spaces, with strict
   consent and dignity guardrails. Provider-pluggable: cheapest pay-per-use
   now, NVIDIA ACE digital-human upgrade path later.

## Files

| File | What it is |
|---|---|
| `server/companionEngine.js` | Complete companion module: onboarding interview, profile extraction, login greeting + next-step, session summaries, check-in email drafts, therapist-bridge cue |
| `server/avatarPipeline.js` | Complete avatar pipeline: consent gate, photo validation (multimodal model), fal.ai generation (default), D-ID + NVIDIA ACE adapters, retire/delete |
| `server/schema.sql` | DB tables for both features |
| `client/AvatarMoment.jsx` | The living-portrait component with labeling + "lay to rest" |

## Secrets required

```
NVIDIA_API_KEY   (already have — companion + photo validation)
FAL_API_KEY      (fal.ai — pay-per-use avatar generation)
IDLE_DRIVER_URL  (URL of an ~8s neutral idle driving clip; see Step 4)
```

---

## PASTE INTO REPLIT AGENT

> Integrate the modules in the `meaningbridge-ai-package` folder. Do not
> redesign them — wire them in.
>
> **Part 1 — Proactive companion (companionEngine.js):**
> 1. Run `schema.sql`. Import `companionEngine.js` server-side.
> 2. **First login:** open the companion chat automatically and drive it with
>    `onboardingTurn(history)`. When the conversation naturally ends (or the
>    user closes it), call `extractProfile(history)` and save to
>    `companion_profiles`.
> 3. **Every login:** call `loginGreeting(context)` — build `context` from
>    real app state (profile, latest `companion_summaries` row, days since
>    last visit, last journal title, next booked session, unfinished
>    reflection, consented nearby important date). Render the greeting at the
>    top of the dashboard with the single suggestion as a warm CTA card that
>    deep-links to the right feature. Cache one greeting per day.
> 4. **After every companion chat or journal session:** call
>    `summarizeSession()` and insert into `companion_summaries`.
> 5. **Weekly cron** (only users with `email_checkins='weekly'`): call
>    `checkinEmail()` and send via our email provider; log to
>    `companion_events`. Every email includes the opt-out line.
> 6. **Monthly per active user:** run `therapistBridgeCue()` on the last 5
>    summaries; if `suggest`, the companion may include one soft invitation
>    to the professional directory in its next conversation — never a popup.
> 7. Companion chat UI: streaming replies, typing indicator, and the existing
>    crisis-support link always visible.
>
> **Part 2 — Living portrait (avatarPipeline.js):**
> 1. `npm i @fal-ai/client`. Import `avatarPipeline.js`.
> 2. In the Loved One profile section, add "Create a living portrait":
>    step 1 shows `CONSENT_TEXT` with an explicit checkbox + typed name to
>    agree (store `consentRecord()` result); step 2 photo upload; step 3 call
>    `createAvatar()`; show a calm progress state ("This takes a minute or
>    two"); on `ok:false` show the returned `guidance` kindly.
> 3. Check fal.ai's current catalog for the best single-image portrait
>    animation model (LivePortrait-style motion transfer; SadTalker for
>    audio-driven) and adjust the model slug in `generateIdlePortrait_fal`
>    if needed. Store the resulting video in our object storage permanently
>    — we pay per generation, never per view.
> 4. Create the idle driver clip once: an 8-second, front-facing, neutral
>    calm video (slow breathing, two blinks, the softest smile at the end) —
>    generate with any video model or record one; host it and set
>    `IDLE_DRIVER_URL`.
> 5. Render `client/AvatarMoment.jsx` ONLY in Meaning Reconstruction spaces:
>    the loved-one profile page and guided rituals. Never on the dashboard,
>    never in chat, never in emails. Respect `status` transitions and wire
>    `onRetire` to `retireAvatar()` — build the short "lay to rest" closing
>    ritual screen (a moment of words, then the portrait fades to a framed
>    still in Keepsakes).
> 6. "Letter moments" (`generateLetterMoment_fal`) ship BEHIND a feature flag,
>    default off, `clinician_gated=true`: only a linked professional can
>    enable it for their client. The voice must be clearly synthetic and
>    neutral — never a clone of the loved one. Wire `neutralTTS` to the
>    cheapest TTS we have.
> 7. Photo + video privacy: signed URLs only, no public buckets; deleting an
>    avatar deletes source photo, videos, and provider artifacts.
>
> **Verify:** new test account → onboarding conversation happens and the
> profile saves → second login greets by name and references the first
> conversation → journal, log out/in, greeting references the journal theme →
> upload a test photo (a public-domain portrait) → consent flow → living
> portrait renders looping in the loved-one profile → "lay to rest" moves it
> to keepsakes → deletion removes files. Show me each step.

---

## Why this beats the "Ask James" route (cost)

NVIDIA's digital-human blueprint (James) is a full 3D ACE stack — Audio2Face-3D,
Riva, RTX rendering — designed for self-hosted GPUs under an NVIDIA AI
Enterprise license. Powerful, but thousands of dollars/month before one user.
The living-portrait path costs **cents per family** (one-time generation,
cached forever) and the UI contract is identical, so swapping in ACE later is
a provider change (`AVATAR_PROVIDER=ace`), not a rebuild.

## Design guardrails (why the pipeline is shaped this way)

An animated likeness of a deceased person is powerful and clinically serious.
The pipeline therefore enforces: explicit consent with rights attestation;
honest labeling (an animation, never "them"); silence by default — it never
initiates, never speaks its own words; user-authored words only, in a neutral
synthetic voice, professional-gated; and a dignified ending ("lay to rest").
These aren't product polish — they're what makes the feature consistent with
Dr. Neimeyer's continuing-bonds approach instead of at odds with it. Please
have your clinical lead review the flow before launch.
