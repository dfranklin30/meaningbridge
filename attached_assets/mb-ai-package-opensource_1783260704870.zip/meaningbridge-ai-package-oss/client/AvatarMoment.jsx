import { useState } from "react";

/**
 * AvatarMoment — the living portrait, shown ONLY inside Meaning
 * Reconstruction spaces (loved-one profile, guided rituals, letter reading).
 * Silent presence by default. Always labeled. Never autoplays with sound.
 */
export default function AvatarMoment({ avatar, moment, onRetire }) {
  const [showRetire, setShowRetire] = useState(false);
  if (!avatar || avatar.status !== "active") return null;

  return (
    <div className="mx-auto max-w-sm">
      <div className="relative overflow-hidden rounded-2xl shadow-lg">
        <video
          src={moment?.video_url || avatar.idle_video_url}
          autoPlay
          loop={!moment}
          muted={!moment}
          playsInline
          className="w-full"
          style={{ filter: "saturate(0.92)", background: "#1f3a68" }}
        />
        {/* soft vignette so the portrait feels held, not clinical */}
        <div
          className="pointer-events-none absolute inset-0 rounded-2xl"
          style={{ boxShadow: "inset 0 0 60px 20px rgba(31,58,104,0.25)" }}
        />
      </div>

      <p className="mt-3 text-center text-sm text-slate-500">
        A living portrait of {avatar.loved_one_name} — a gentle AI animation
        created from your photo, to help you hold their memory close.
      </p>

      <div className="mt-2 flex justify-center gap-4 text-xs text-slate-400">
        <button onClick={() => setShowRetire(true)} className="underline">
          Lay this portrait to rest
        </button>
      </div>

      {showRetire && (
        <div className="mt-4 rounded-xl border border-slate-200 bg-white p-4 text-sm">
          <p className="text-slate-600">
            When you're ready, you can lay this portrait to rest. We'll close
            with a short ritual, and it will move to your keepsakes. You can
            also delete it permanently — everywhere, forever.
          </p>
          <div className="mt-3 flex gap-3">
            <button
              className="rounded-lg bg-slate-800 px-3 py-1.5 text-white"
              onClick={() => onRetire("retire")}
            >
              Lay to rest
            </button>
            <button
              className="rounded-lg border border-slate-300 px-3 py-1.5"
              onClick={() => onRetire("delete")}
            >
              Delete permanently
            </button>
            <button className="px-2" onClick={() => setShowRetire(false)}>
              Not now
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
