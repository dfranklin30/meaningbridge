/**
 * MeaningBridge Loved-One Avatar Pipeline ("Living Portrait")
 *
 * Turns a single uploaded photo of a lost loved one into a gently animated
 * "living portrait" (subtle breathing, blinking, soft smile) used inside the
 * Meaning Reconstruction sections. Provider-pluggable:
 *
 *   provider = "fal"   → fal.ai hosted SadTalker/LivePortrait (pay-per-use,
 *                        cheapest; no monthly fee)            [DEFAULT]
 *   provider = "did"   → D-ID talking-photo API (subscription, more polish)
 *   provider = "ace"   → stub for NVIDIA ACE / Audio2Face-3D digital human
 *                        (self-hosted GPU; future upgrade path)
 *
 * ETHICS GUARDRAILS (enforced here, not optional):
 *  1. Explicit consent + rights attestation before any processing.
 *  2. The portrait is clearly labeled an AI animation — never "them".
 *  3. Silent presence by default. The avatar has NO generative voice and
 *     NEVER initiates. Optional "letter moments" animate ONLY text the user
 *     wrote themselves, in a clearly synthetic neutral voice.
 *  4. Recommended clinician gating for speaking moments (Specialist tier).
 *  5. A "lay to rest" (retire) action that archives the portrait with a
 *     closing ritual. Deletion is honored everywhere including the provider.
 *
 * Env: FAL_API_KEY  (and/or DID_API_KEY)
 * DB:  see schema.sql — table loved_one_avatars
 */

const PROVIDER = process.env.AVATAR_PROVIDER || "fal";

// ----------------------------------------------------------- 1. Consent gate
const CONSENT_TEXT = `
I confirm I have the right to use this photograph, and I understand that
MeaningBridge will create a gently animated portrait from it. This portrait is
an artistic AI animation to support my grief work — it is not, and cannot be,
my loved one. I can pause, retire, or permanently delete it at any time.
`.trim();

/** Must be recorded (user id, timestamp, text version) before createAvatar. */
function consentRecord(userId) {
  return { userId, consentText: CONSENT_TEXT, version: 1, at: new Date().toISOString() };
}

// ---------------------------------------------------- 2. Photo validation
/**
 * Server-side checks before spending on generation:
 * - image type/size (jpg/png/webp, <=10MB)
 * - exactly one clear face (run a cheap face-detect; reject group photos
 *   with guidance: "Please choose a photo where {name} is alone and facing
 *   the camera.")
 * Implement face detect with the multimodal companion model — one call:
 */
async function validatePhoto(base64Image) {
  const res = await fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.NVIDIA_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "nvidia/nemotron-3-nano-omni-30b-a3b",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text:
                'Answer JSON only: {"faces": <int>, "clear": true|false, ' +
                '"frontal": true|false, "notes": "..."} for this photo.',
            },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${base64Image}` } },
          ],
        },
      ],
      max_tokens: 100,
      response_format: { type: "json_object" },
    }),
  });
  const data = await res.json();
  const check = JSON.parse(data.choices[0].message.content);
  return { ok: check.faces === 1 && check.clear, check };
}

// ------------------------------------------- 3. Generation (fal.ai default)
/**
 * Creates the idle "living portrait" loop: ~8s of subtle breathing/blinks,
 * played on loop in the UI with a soft vignette. Uses fal.ai's hosted
 * image-animation models (SadTalker for speaking; LivePortrait-style motion
 * for idle). Pay-per-generation — you only pay when a family creates or
 * updates a portrait, which is rare. Cache the video forever.
 *
 * NOTE FOR REPLIT AGENT: check fal.ai's current model catalog and use their
 * @fal-ai/client npm package; the queue/submit pattern below is the shape.
 */
async function generateIdlePortrait_fal(imageUrl) {
  const { fal } = require("@fal-ai/client"); // npm i @fal-ai/client
  fal.config({ credentials: process.env.FAL_API_KEY });

  // Driven-motion animation from a single image. A neutral, slow "idle"
  // driving clip (we ship one: assets/idle-driver.mp4 — 8s of calm breathing
  // and two blinks) is applied to the uploaded photo.
  const result = await fal.subscribe("fal-ai/live-portrait", {
    input: {
      image_url: imageUrl,
      video_url: process.env.IDLE_DRIVER_URL, // our neutral driving clip
      flag_pasteback: true,
    },
  });
  return result.data.video.url; // store permanently in our storage
}

/**
 * OPTIONAL "letter moment": animates the portrait reading text THE USER
 * WROTE (e.g., a letter of things left unsaid, read back during a guided
 * ritual). Voice is a clearly synthetic, neutral, gentle voice — we do NOT
 * clone the loved one's voice. Gate behind clinician recommendation.
 */
async function generateLetterMoment_fal(imageUrl, userWrittenText) {
  const { fal } = require("@fal-ai/client");
  fal.config({ credentials: process.env.FAL_API_KEY });

  // 1) TTS with a neutral voice (any low-cost TTS; or browser TTS client-side
  //    recorded once). 2) Lip-synced animation:
  const audioUrl = await neutralTTS(userWrittenText); // implement with chosen TTS
  const result = await fal.subscribe("fal-ai/sadtalker", {
    input: { source_image_url: imageUrl, driven_audio_url: audioUrl, still_mode: true },
  });
  return result.data.video.url;
}

// ------------------------------------- OPEN-SOURCE adapter (no fal, no D-ID)
/**
 * provider = "oss": fully open-source models (LivePortrait — KwaiVGI,
 * Apache-style license; SadTalker for audio-driven) running on YOUR OWN
 * GPU worker. No third-party AI API at all.
 *
 * Replit has no GPUs, so run the worker on any on-demand GPU host
 * (e.g. RunPod serverless, vast.ai, or a small cloud GPU VM). The worker is
 * a ~50-line FastAPI wrapper around LivePortrait's inference script:
 *
 *   POST ${OSS_AVATAR_WORKER_URL}/animate
 *   { "image_url": "...", "driver_url": "...", "mode": "idle" | "audio",
 *     "audio_url": null }
 *   → { "video_url": "..." }   (worker uploads result to our object storage)
 *
 * Since generation is one-time per family and cached forever, an on-demand
 * worker that cold-starts per job costs pennies — and every model in the
 * chain is open source.
 *
 * Env: OSS_AVATAR_WORKER_URL, OSS_AVATAR_WORKER_TOKEN
 */
async function generateIdlePortrait_oss(imageUrl) {
  const res = await fetch(`${process.env.OSS_AVATAR_WORKER_URL}/animate`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OSS_AVATAR_WORKER_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      image_url: imageUrl,
      driver_url: process.env.IDLE_DRIVER_URL,
      mode: "idle",
    }),
  });
  if (!res.ok) throw new Error(`OSS avatar worker error ${res.status}`);
  return (await res.json()).video_url;
}

async function generateLetterMoment_oss(imageUrl, userWrittenText) {
  // TTS: open source too — Piper or Coqui-TTS on the same worker (neutral
  // voice model only; never a voice clone of the loved one).
  const res = await fetch(`${process.env.OSS_AVATAR_WORKER_URL}/animate`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OSS_AVATAR_WORKER_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ image_url: imageUrl, mode: "audio", text: userWrittenText }),
  });
  if (!res.ok) throw new Error(`OSS avatar worker error ${res.status}`);
  return (await res.json()).video_url;
}

// --------------------------------------------------- D-ID adapter (upgrade)
async function generateIdlePortrait_did(imageUrl) {
  // POST https://api.d-id.com/animations  { source_url, driver: "subtle" }
  // Authorization: Basic DID_API_KEY. Poll GET /animations/{id} → result_url.
  throw new Error("Enable by setting AVATAR_PROVIDER=did and implementing per D-ID docs");
}

// ------------------------------------------------- NVIDIA ACE stub (future)
async function generateIdlePortrait_ace() {
  // Full 3D digital human (NVIDIA digital-human blueprint: Audio2Face-3D +
  // Riva + RTX rendering). Requires self-hosted GPUs / NVIDIA AI Enterprise.
  // Revisit when budget supports it; the UI contract (a looping video / live
  // stream in <AvatarMoment/>) stays identical.
  throw new Error("ACE path not enabled");
}

// ----------------------------------------------------------- 4. Orchestrator
async function createAvatar({ userId, lovedOneName, imageUrl, base64Image, consent }) {
  if (!consent || consent.consentText !== CONSENT_TEXT)
    throw new Error("Consent required before creating a living portrait.");

  const v = await validatePhoto(base64Image);
  if (!v.ok)
    return { ok: false, guidance: `We couldn't use this photo (${v.check.notes}). Please choose one where ${lovedOneName} is alone, facing the camera, in good light.` };

  const generators = { fal: generateIdlePortrait_fal, oss: generateIdlePortrait_oss, did: generateIdlePortrait_did, ace: generateIdlePortrait_ace };
  const videoUrl = await generators[PROVIDER](imageUrl);

  return {
    ok: true,
    record: {
      user_id: userId,
      loved_one_name: lovedOneName,
      source_image_url: imageUrl,
      idle_video_url: videoUrl,
      provider: PROVIDER,
      status: "active", // active | paused | retired | deleted
      consent_json: JSON.stringify(consent),
      created_at: new Date().toISOString(),
    },
  };
}

/** "Lay to rest": archive with a closing ritual; delete removes everything. */
async function retireAvatar(db, avatarId, mode /* "retire" | "delete" */) {
  if (mode === "delete") {
    // delete stored media + provider-side artifacts, then the row
    // (implement storage + provider deletion here)
  }
  return db.updateAvatarStatus(avatarId, mode === "delete" ? "deleted" : "retired");
}

module.exports = { CONSENT_TEXT, consentRecord, validatePhoto, createAvatar, retireAvatar };

// placeholder — wire to your chosen low-cost TTS
async function neutralTTS(text) { throw new Error("wire neutralTTS to chosen TTS provider"); }
