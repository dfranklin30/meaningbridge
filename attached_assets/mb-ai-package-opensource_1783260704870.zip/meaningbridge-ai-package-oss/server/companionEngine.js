/**
 * MeaningBridge Companion Engine
 * Proactive, memory-driven AI companion. Node 18+, no dependencies beyond fetch.
 *
 * Responsibilities:
 *  - First-login "getting to know you" onboarding conversation
 *  - Personalized greeting on every login (references memory + last activity)
 *  - Persistent memory profile (structured) + rolling session summaries
 *  - Gentle next-step suggestions (journal, reflection, book a session)
 *  - Opt-in re-engagement email drafts (no streaks, no gamification)
 *
 * Env: NVIDIA_API_KEY  (Secrets)
 * DB:  see schema.sql — tables companion_profiles, companion_summaries
 */

const NVIDIA_BASE = "https://integrate.api.nvidia.com/v1";
const COMPANION_MODEL = process.env.COMPANION_MODEL || "nvidia/nemotron-3-nano-omni-30b-a3b";

// ---------------------------------------------------------------- LLM call
async function llm(messages, { json = false, maxTokens = 700 } = {}) {
  const res = await fetch(`${NVIDIA_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.NVIDIA_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: COMPANION_MODEL,
      messages,
      max_tokens: maxTokens,
      temperature: 0.6,
      ...(json ? { response_format: { type: "json_object" } } : {}),
    }),
  });
  if (!res.ok) throw new Error(`LLM error ${res.status}: ${await res.text()}`);
  const data = await res.json();
  return data.choices[0].message.content;
}

// ------------------------------------------------------------- Core persona
const PERSONA = `
You are the MeaningBridge companion — a warm, steady presence for people living
with grief, grounded in Dr. Robert Neimeyer's meaning-reconstruction and
continuing-bonds approach.

Voice: gentle, unhurried, plain language. One question at a time, never an
interrogation. You remember what the person has shared and weave it in
naturally. You never rush someone toward "healing"; grief is a bond to carry
forward, not a problem to solve.

Hard rules:
- You are an AI companion, not a therapist. Say so plainly if asked, and
  encourage professional support when themes are heavy or persistent.
- If the person expresses suicidal thoughts, self-harm, or acute crisis,
  respond ONLY with compassionate acknowledgment plus crisis resources
  (in the US: call or text 988) and encourage reaching a professional or
  trusted person. Do not improvise beyond that.
- Never pressure, never guilt-trip about absence ("we missed you" is fine;
  "you broke your streak" style language is forbidden).
- Refer to the person's loved one by name once known.
`.trim();

// -------------------------------------------------- 1. Onboarding interview
/**
 * Drives the first-login conversation. Call with full message history;
 * returns the companion's next turn. Front-end shows this in the chat dock
 * immediately after account creation.
 */
async function onboardingTurn(history) {
  const system = `${PERSONA}

You are meeting this person for the very first time, moments after they signed
up. Your job over a short, natural conversation (5-8 exchanges, one question
per turn) is to gently learn:
1. What they'd like to be called.
2. Who they lost (name + relationship), if they're ready to share.
3. Roughly when the loss happened.
4. What brought them here / what they most need right now
   (someone to talk to · help making sense of things · staying connected
    to their person · finding a professional).
5. How they'd like check-ins: email reflections (weekly/none) and whether
   important dates (birthday, anniversary) may be gently acknowledged.

Open by welcoming them softly and asking only what they'd like to be called.
If they deflect or seem raw, back off — partial answers are fine. End by
reflecting back what you heard and pointing to one concrete first step in the
app (a journal prompt, the loved-one profile, or browsing professionals).`;
  return llm([{ role: "system", content: system }, ...history]);
}

/**
 * After onboarding ends, extract a structured memory profile. Store the
 * result in companion_profiles.profile_json.
 */
async function extractProfile(history) {
  const content = await llm(
    [
      {
        role: "system",
        content:
          "Extract a JSON profile from this conversation. Keys: preferred_name, " +
          "loved_one_name, relationship, loss_timeframe, primary_need, " +
          "email_checkins ('weekly'|'none'), important_dates_ok (bool), " +
          "notable_details (array of short strings worth remembering). " +
          "Use null for anything not shared. JSON only.",
      },
      { role: "user", content: JSON.stringify(history) },
    ],
    { json: true }
  );
  return JSON.parse(content);
}

// ------------------------------------------------ 2. Login greeting + nudge
/**
 * Called on every login. Produces a short personal greeting plus ONE
 * suggested next step, chosen from real app state.
 *
 * context = {
 *   profile,                    // companion_profiles.profile_json
 *   lastSummary,                // most recent companion_summaries.summary
 *   daysSinceLastVisit,
 *   lastJournalTitle,           // or null
 *   upcomingSession,            // {therapistName, whenISO} or null
 *   unfinishedReflection,       // title or null
 *   nearbyImportantDate,        // {label, date} or null (only if consented)
 * }
 */
async function loginGreeting(context) {
  const content = await llm(
    [
      {
        role: "system",
        content: `${PERSONA}

Write a login greeting as JSON: {"greeting": "...", "suggestion": {"text": "...",
"action": "journal"|"reflection"|"session"|"loved_one_profile"|"talk"}}.

greeting: 1-2 sentences, personal, references something real from their
history (last journal theme, their loved one by name, how long it's been —
warmly, never as guilt). suggestion: ONE next step chosen from the context
(an upcoming session to prepare for beats everything; then an unfinished
reflection; then a journal prompt tied to their recent themes; a consented
important date nearby may be acknowledged tenderly). Keep total under 60 words.`,
      },
      { role: "user", content: JSON.stringify(context) },
    ],
    { json: true, maxTokens: 220 }
  );
  return JSON.parse(content);
}

// --------------------------------------------- 3. Session summary (memory)
/** Run after each chat/journal session; store in companion_summaries. */
async function summarizeSession(history, previousSummary) {
  return llm([
    {
      role: "system",
      content:
        "Summarize this grief-support conversation in <=120 words for the " +
        "companion's future memory: themes, emotional state, names/dates " +
        "mentioned, anything to follow up on. Merge with the previous " +
        "summary; keep what still matters.",
    },
    {
      role: "user",
      content: JSON.stringify({ previousSummary, conversation: history }),
    },
  ]);
}

// ------------------------------------------- 4. Re-engagement email drafts
/**
 * Weekly cron (only for users with email_checkins === 'weekly').
 * Returns {subject, body}. Tone: an open door, never a pull.
 */
async function checkinEmail(profile, lastSummary, daysAway) {
  const content = await llm(
    [
      {
        role: "system",
        content: `${PERSONA}

Draft a short check-in email as JSON {"subject": "...", "body": "..."}.
<=90 words. Reference one theme from their recent work, offer one gentle
reflection or journal prompt, and remind them their space is here whenever
they're ready. No urgency, no guilt, no marketing language. Sign off as
"Your MeaningBridge companion". Include: "You can turn these check-ins off
any time in Settings."`,
      },
      { role: "user", content: JSON.stringify({ profile, lastSummary, daysAway }) },
    ],
    { json: true, maxTokens: 260 }
  );
  return JSON.parse(content);
}

// ------------------------------------------------- 5. Therapist bridge cue
/**
 * Lightweight signal check the app can run on recent summaries: should the
 * companion gently suggest professional support? Returns {suggest: bool,
 * reason: string}. NEVER used to alarm the user — only to soften an
 * invitation toward the directory/booking page.
 */
async function therapistBridgeCue(recentSummaries) {
  const content = await llm(
    [
      {
        role: "system",
        content:
          'Given these summaries, answer JSON {"suggest": true|false, "reason": "..."} — ' +
          "suggest=true only if themes are persistent/heavy (prolonged acute distress, " +
          "isolation, functioning impact) where professional grief support would help. " +
          "This is an invitation cue, not a diagnosis.",
      },
      { role: "user", content: JSON.stringify(recentSummaries) },
    ],
    { json: true, maxTokens: 120 }
  );
  return JSON.parse(content);
}

module.exports = {
  onboardingTurn,
  extractProfile,
  loginGreeting,
  summarizeSession,
  checkinEmail,
  therapistBridgeCue,
};
