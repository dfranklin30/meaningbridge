-- MeaningBridge AI package — database additions (non-PHI side)
-- NOTE: if/when the HIPAA architecture lands, clinical data lives in Healthie;
-- these tables hold companion + avatar app data.

CREATE TABLE IF NOT EXISTS companion_profiles (
  user_id        TEXT PRIMARY KEY,
  profile_json   TEXT NOT NULL,           -- extractProfile() output
  email_checkins TEXT DEFAULT 'none',     -- 'weekly' | 'none'
  dates_ok       BOOLEAN DEFAULT FALSE,   -- may acknowledge important dates
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS companion_summaries (
  id         SERIAL PRIMARY KEY,
  user_id    TEXT NOT NULL,
  summary    TEXT NOT NULL,               -- summarizeSession() output
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_summaries_user ON companion_summaries(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS companion_events (
  id         SERIAL PRIMARY KEY,
  user_id    TEXT NOT NULL,
  kind       TEXT NOT NULL,               -- 'login' | 'journal' | 'reflection' | 'checkin_sent' | 'bridge_suggested'
  meta_json  TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS loved_one_avatars (
  id               SERIAL PRIMARY KEY,
  user_id          TEXT NOT NULL,
  loved_one_name   TEXT NOT NULL,
  source_image_url TEXT NOT NULL,
  idle_video_url   TEXT NOT NULL,
  provider         TEXT NOT NULL,         -- 'fal' | 'did' | 'ace'
  status           TEXT DEFAULT 'active', -- 'active' | 'paused' | 'retired' | 'deleted'
  consent_json     TEXT NOT NULL,         -- full consent record, versioned
  clinician_gated  BOOLEAN DEFAULT TRUE,  -- speaking moments require professional ok
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS avatar_moments (
  id           SERIAL PRIMARY KEY,
  avatar_id    INTEGER NOT NULL REFERENCES loved_one_avatars(id),
  kind         TEXT NOT NULL,             -- 'idle' | 'letter'
  user_text    TEXT,                      -- letter moments: the user's own words only
  video_url    TEXT NOT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
